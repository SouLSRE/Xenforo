<?php

namespace XF\Alert;

class Report extends AbstractHandler {}